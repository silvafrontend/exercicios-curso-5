def eh_par(numero):
    return numero % 2 == 0

numeros_teste = [0, 7, 10, -4]

for num in numeros_teste:
    if eh_par(num):
        print(f"O número {num} é PAR.")
    else:
        print(f"O número {num} é ÍMPAR.")
