def mostrar_abertura():
    print("-" * 35)
    print("Curso: Introdução à Programação")
    print("Seja muito bem-vindo(a)!")
    print("-" * 35)

mostrar_abertura()
mostrar_abertura()
