def contar_classificacao(previsoes, categoria):
    contador = 0
    for item in previsoes:
        if item == categoria:
            contador += 1
    return contador

previsoes_exemplo = ["gato", "cachorro", "gato", "pássaro", "gato"]

print("Gato:", contar_classificacao(previsoes_exemplo, "gato"))
print("Cachorro:", contar_classificacao(previsoes_exemplo, "cachorro"))
print("Peixe:", contar_classificacao(previsoes_exemplo, "peixe"))
