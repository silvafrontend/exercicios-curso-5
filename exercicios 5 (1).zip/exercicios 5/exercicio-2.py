def apresentar_aluno(nome, curso):
    print(f"O(A) estudante {nome} está matriculado(a) no curso de {curso}.")

nome_input = input("Digite o nome do aluno: ")
curso_input = input("Digite o nome do curso: ")

print("\n--- Chamada Posicional ---")
apresentar_aluno(nome_input, curso_input)

print("\n--- Chamada Nomeada ---")
apresentar_aluno(curso=curso_input, nome=nome_input)
