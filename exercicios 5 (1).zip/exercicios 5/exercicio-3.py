def calcular_area_retangulo(base, altura):
    return base * altura

base_retangulo = float(input("Digite a base do retângulo: "))
altura_retangulo = float(input("Digite a altura do retângulo: "))

area = calcular_area_retangulo(base_retangulo, altura_retangulo)
print(f"A área do retângulo é: {area:.1f}")
