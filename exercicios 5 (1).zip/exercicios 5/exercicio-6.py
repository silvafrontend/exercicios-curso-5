def calcular_media(notas):
    if not notas:
        return None
    return sum(notas) / len(notas)

testes_notas = [
    [8.0, 6.0, 10.0],
    [0.0, 0.0],
    []
]

for lista in testes_notas:
    media = calcular_media(lista)
    
    if media is None:
        print(f"Lista {lista}: Não foi possível calcular a média (lista vazia).")
    else:
        print(f"Lista {lista}: A média é {media:.1f}")
