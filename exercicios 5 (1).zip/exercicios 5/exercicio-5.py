def saudar(nome, saudacao="Olá"):
    return f"{saudacao}, {nome}!"

saudacao_1 = saudar("Lucas")
print(saudacao_1)

saudacao_2 = saudar("Maria", "Boa noite")
print(saudacao_2)
